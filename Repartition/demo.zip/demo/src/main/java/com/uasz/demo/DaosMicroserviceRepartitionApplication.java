package com.uasz.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DaosMicroserviceRepartitionApplication {

	public static void main(String[] args) {
		SpringApplication.run(DaosMicroserviceRepartitionApplication.class, args);
	}

}
